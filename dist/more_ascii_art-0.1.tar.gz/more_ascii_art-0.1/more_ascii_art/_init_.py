# cat image in ascii art
def cat():
    print(" _                   ")
    print("( \                  ")
    print(" ) )                 ")
    print("( (                  ")
