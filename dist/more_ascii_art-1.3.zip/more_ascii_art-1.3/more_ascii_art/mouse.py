def mouse():
  # Mouse prints go here
  print('       ____()()')
  print('      /      @@')
  print('`~~~~~\_;m__m._>o ')
