# A cat in ASCII art

def cat():
  print(" _")
  print("( \ ")
  print(" ) )")
  print("( (  .-''''-.  A.-.A")
  print("\ \/         \/  , ,  \ ")
  print(" \    \      =;   t   / = ")
  print("  \    |''''.  ' ,-- ' ")
  print("   /  //    | || ")
  print("  /_ ,))    |_,)) ")
        
