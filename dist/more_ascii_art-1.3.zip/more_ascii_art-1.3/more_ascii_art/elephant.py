# drawing an elephant
def elephant():
  print("          __     __ ")
  print("         /  \~~~/  \  ")
  print("   ,----(     . .   )  ")
  print("  /      \__     __/   ")
  print(" /|         (\  |( ")
  print("^ \   /__\   /\ | ")
  print("  |__|   |__|-'' ")
